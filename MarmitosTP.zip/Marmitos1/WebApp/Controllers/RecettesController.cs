﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DataModel.BusinessLayer;
using DataModel.BusinessObject;
using DataModel.DataAccessLayer;

namespace WebApp.Controllers
{
    public class RecettesController : Controller
    {
        private RecetteManager RM = new RecetteManager();

        // GET: Recettes
        public ActionResult Index()
        {
            return View(RM.GetAll());
        }

        // GET: Recettes/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Recette recette = (Recette)RM.GetById((int)id);
            if (recette == null)
            {
                return HttpNotFound();
            }
            return View(recette);
        }

        // GET: Recettes/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Recettes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "RecetID,RecetNom,RecetCout")] Recette recette)
        {
            if (ModelState.IsValid)
            {
                RM.Insert(recette);
                return RedirectToAction("Index");
            }

            return View(recette);
        }

        // GET: Recettes/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Recette recette = (Recette)RM.GetById((int)id);
            if (recette == null)
            {
                return HttpNotFound();
            }
            return View(recette);
        }

        // POST: Recettes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "RecetID,RecetNom,RecetCout")] Recette recette)
        {
            if (ModelState.IsValid)
            {
                RM.Update(recette);
                return RedirectToAction("Index");
            }
            return View(recette);
        }

        // GET: Recettes/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Recette recette = RM.GetById((int)id);
            if (recette == null)
            {
                return HttpNotFound();
            }
            return View(recette);
        }

        // POST: Recettes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            RM.Delete(RM.GetById(id));
            return RedirectToAction("Index");
        }
    }
}
