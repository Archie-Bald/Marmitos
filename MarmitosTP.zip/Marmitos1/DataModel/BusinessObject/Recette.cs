﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel.BusinessObject
{
    public class Recette
    {
        [Key]
        public int RecetID { get; set; }
        [Display(Name = "Nom")]
        public string RecetNom { get; set; }
        [Display(Name = "Coût")]
        public double RecetCout { get; set; }
        [Display(Name = "Temps")]
        public float RecetTemps { get; set; }

        public virtual ICollection<RecetIngr> RecetIngredient { get; set; }
    }
}
