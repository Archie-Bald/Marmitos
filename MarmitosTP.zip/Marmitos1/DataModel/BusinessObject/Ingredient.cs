﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel.BusinessObject
{
    public class Ingredient
    {
        [Key]
        public int IngId { get; set; }

        [Display(Name = "Nom")]
        public string IngNom { get; set; }
        [Display(Name ="Unité")]
        public Unite IngUnit { get; set; }
        [Display(Name = "Prix")]
        public double IngPrix { get; set; }

        public virtual ICollection<RecetIngr> IngRecette { get; set; }
    }
}
