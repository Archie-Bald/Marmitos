﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel.BusinessObject
{
    public class Unite
    {
        [Key]
        public int UnitID { get; set; }
        [Display(Name = "Nom")]
        public string UnitNom { get; set; }
        [Display(Name = "Abréviation")]
        public string UnitDiminutif { get; set; }
    }
}
