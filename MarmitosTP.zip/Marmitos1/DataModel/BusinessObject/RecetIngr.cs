﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel.BusinessObject
{
    public class RecetIngr
    {
        [Key]
        [Column(Order=0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int RecID { get; set; }
        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IngId { get; set; }

        public virtual Recette LaRecette { get; set; }
        public virtual Ingredient MonIngredient { get; set; }

        [Display(Name = "Quantité")]
        public float Quantite { get; set; }

    }
}
