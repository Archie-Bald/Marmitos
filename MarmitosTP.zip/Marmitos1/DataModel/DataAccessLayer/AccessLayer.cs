﻿namespace DataModel.DataAccessLayer
{
    using DataModel.BusinessObject;
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class AccessLayer : DbContext
    {
        // Votre contexte a été configuré pour utiliser une chaîne de connexion « DataAccessLayer » du fichier 
        // de configuration de votre application (App.config ou Web.config). Par défaut, cette chaîne de connexion cible 
        // la base de données « DataModel.DataAccessLayer.DataAccessLayer » sur votre instance LocalDb. 
        // 
        // Pour cibler une autre base de données et/ou un autre fournisseur de base de données, modifiez 
        // la chaîne de connexion « DataAccessLayer » dans le fichier de configuration de l'application.
        public AccessLayer()
            : base("name=DataAccessLayer")
        {
            Database.SetInitializer<AccessLayer>(new CreateDatabaseIfNotExists<AccessLayer>());
        }
        // Ajoutez un DbSet pour chaque type d'entité à inclure dans votre modèle. Pour plus d'informations 
        // sur la configuration et l'utilisation du modèle Code First, consultez http://go.microsoft.com/fwlink/?LinkId=390109.
        private static AccessLayer DAL { get; set; }


        // Ajoutez un DbSet pour chaque type d'entité à inclure dans votre modèle. Pour plus d'informations 
        // sur la configuration et l'utilisation du modèle Code First, consultez http://go.microsoft.com/fwlink/?LinkId=390109.
        public static AccessLayer GetInstance()
        {
            if (DAL == null)
            {
                DAL = new AccessLayer();
            }
            return DAL;
        }
        public virtual DbSet<Unite> Unites { get; set; }
        public virtual DbSet<Recette> Unite { get; set; }
        public virtual DbSet<Ingredient> Ingredients { get; set; }
        public virtual DbSet<RecetIngr> RecetIng { get; set; }

    }

    //public class MyEntity
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }
    //}
}