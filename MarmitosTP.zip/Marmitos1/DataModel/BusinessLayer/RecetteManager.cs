﻿using DataModel.BusinessObject;
using DataModel.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel.BusinessLayer
{
    public class RecetteManager
    {
    
        public IEnumerable<Recette> GetAll()
        {
            return AccessLayer.GetInstance().Set<Recette>().ToList();
        }

        public Recette GetById(int monId)
        {
            return AccessLayer.GetInstance().Set<Recette>().Find(monId);
        }

        public Recette Insert(Recette monobjet)
        {
            AccessLayer.GetInstance().Set<Recette>().Add((Recette) monobjet);
            AccessLayer.GetInstance().SaveChanges();
            return (Recette)monobjet;
        }

        public Recette Update(Recette monobjet)
        {
            Recette AvantMAJ = AccessLayer.GetInstance().Unite.Find(monobjet.RecetID);
            if(AvantMAJ == null)
            {
                return monobjet;
            }
            else
            {
                AccessLayer.GetInstance().Entry(AvantMAJ).CurrentValues.SetValues(monobjet);
                AccessLayer.GetInstance().SaveChanges();
            }
            return monobjet;
        }

        public void Delete(Recette monobjet)
        {
            AccessLayer.GetInstance().Set<Recette>().Remove((Recette)monobjet);
            AccessLayer.GetInstance().SaveChanges();
        }

    }
}
