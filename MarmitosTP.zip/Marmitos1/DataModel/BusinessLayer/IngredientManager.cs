﻿using DataModel.BusinessObject;
using DataModel.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel.BusinessLayer
{
    public class IngredientManager
    {
        //public UniteManager UM { get; set; }
        //public IEnumerable<Unite> GetUnites()
        //{
        //    return UM.GetAll();
        //}

        public IEnumerable<Ingredient> GetAll()
        {
            return AccessLayer.GetInstance().Set<Ingredient>().ToList();
        }

        public Ingredient GetById(int monId)
        {
            return AccessLayer.GetInstance().Set<Ingredient>().Find(monId);
        }

        public Ingredient Insert(Ingredient monobjet)
        {
            AccessLayer.GetInstance().Set<Ingredient>().Add((Ingredient)monobjet);
            AccessLayer.GetInstance().SaveChanges();
            return (Ingredient)monobjet;
        }

        public List<Ingredient> GetByName(string myname)
        {
            return AccessLayer.GetInstance().Ingredients.Where(i => i.IngNom == myname).ToList();
        }

        public Ingredient Update(Ingredient monobjet)
        {
            Ingredient AvantMAJ = AccessLayer.GetInstance().Ingredients.Find(monobjet.IngId);
            if (AvantMAJ == null)
            {
                return monobjet;
            }
            else
            {
                AccessLayer.GetInstance().Entry(AvantMAJ).CurrentValues.SetValues(monobjet);
                AccessLayer.GetInstance().SaveChanges();
            }
            return monobjet;
        }

        public void Delete(int ingredientId)
        {
            AccessLayer.GetInstance().Set<Ingredient>().Remove(GetById(ingredientId));
            AccessLayer.GetInstance().SaveChanges();
        }

    }
}
