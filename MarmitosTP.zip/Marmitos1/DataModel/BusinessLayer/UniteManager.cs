﻿using DataModel.BusinessObject;
using DataModel.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel.BusinessLayer
{
    public class UniteManager
    {

        public IEnumerable<Unite> GetAll()
        {
            return AccessLayer.GetInstance().Unites.ToList();
        }

        public Unite GetById(int monId)
        {
            return AccessLayer.GetInstance().Set<Unite>().Find(monId);
        }

        public Unite Insert(Unite monobjet)
        {
            AccessLayer.GetInstance().Set<Unite>().Add((Unite)monobjet);
            AccessLayer.GetInstance().SaveChanges();
            return (Unite)monobjet;
        }

        public Unite Update(Unite monobjet)
        {
            Unite AvantMAJ = AccessLayer.GetInstance().Unites.Find(monobjet.UnitID);
            if (AvantMAJ == null)
            {
                return monobjet;
            }
            else
            {
                AccessLayer.GetInstance().Entry(AvantMAJ).CurrentValues.SetValues(monobjet);
                AccessLayer.GetInstance().SaveChanges();
            }
            return monobjet;
        }

        public void Delete(Unite monobjet)
        {
            AccessLayer.GetInstance().Set<Unite>().Remove((Unite)monobjet);
            AccessLayer.GetInstance().SaveChanges();
        }

    }
}
